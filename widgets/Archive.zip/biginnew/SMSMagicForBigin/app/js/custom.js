var magicToast = null;
var magicInputToast = null;
var baseURLAPIName = "smsmagic4bigin__Base_URL";

function saveOrgVar(apiName, apiValue) {
  let params = {"apiname": apiName, "value": apiValue};
  ZOHO.BIGIN.CONNECTOR.invokeAPI("crm.set", params).then(function (data) {
      console.log(JSON.stringify(data));
      magicToast.show();
  });
}

function selectDataCenter(dc) {
  console.log('Selected DC: ' + dc);
  $("#usdc").removeClass('disabled');
  $("#eudc").removeClass('disabled');
  $("#audc").removeClass('disabled');
  $("#otherdc").removeClass('disabled');
  if (dc == 1) {
    $("#usdc").addClass('disabled');
    saveOrgVar(baseURLAPIName, "https://app.sms-magic.com");
    $("#selected-dc").html('US data center');
  } else if (dc == 2) {
    $("#eudc").addClass('disabled');
    saveOrgVar(baseURLAPIName, "https://eu,app.sms-magic.com");
    $("#selected-dc").html('EU data center');
  } else if (dc == 3) {
    $("#audc").addClass('disabled');
    saveOrgVar(baseURLAPIName, "https://aus-app.sms-magic.com");
    $("#selected-dc").html('AU data center');
  } else {
    magicInputToast.show();
  }
}

$(document).cli

$(document).ready(function () {
  magicToast = bootstrap.Toast.getOrCreateInstance(document.getElementById('magictoast'));
  magicInputToast = bootstrap.Toast.getOrCreateInstance(document.getElementById('magicinputtoast'));
  console.log("Document is ready " + magicToast);

  $("#otherdcsavebtn").click(function(){
    let otherDCURL = $('#otherdcinputurl').val();
    if (otherDCURL != undefined || otherDCURL !== "" || otherDCURL != null) {
      saveOrgVar(baseURLAPIName, otherDCURL);
      $("#selected-dc").html('Custom data center');
    }
  });

  /*
   * Subscribe to the EmbeddedApp onPageLoad event before
   * initializing the widget
   */
  ZOHO.embeddedApp.on("PageLoad", function (data) {
    console.log("PageLoad is complete" + JSON.stringify(data, null, 2));
    /*
     * Verify if EntityInformation is Passed
     */
    if (data && data.Entity) {
      /*
       * Fetch Information of Record passed in PageLoad
       * and insert the response into the dom
       */
      console.log("Fetching data: " + JSON.stringify(ZOHO, null, 2));
      ZOHO.BIGIN.API.getRecord({
        Entity: data.Entity,
        RecordID: data.EntityId,
      }).then(function (response) {
        console.log("ZOHO.BIGIN.API.getRecord: " + JSON.stringify(response, null, 2));
        $("#recordInfo").html(JSON.stringify(response));
      });
    }

   /*
    * Fetch Current User Information from CRM
    * and insert the response into the dom
    */
    ZOHO.BIGIN.CONFIG.getCurrentUser().then(function (response) {
      console.log("ZOHO.BIGIN.CONFIG.getCurrentUser: " + JSON.stringify(response, null, 2));
      $("#userInfo").html(JSON.stringify(response));
    });

    /*
     * Fetch Current User Information from CRM
     * and insert the response into the dom
     */
    ZOHO.BIGIN.CONFIG.getCurrentUser().then(function (response) {
      console.log("ZOHO.BIGIN.CONFIG.getCurrentUser: " + JSON.stringify(response, null, 2));
      $("#userInfo").html(JSON.stringify(response));
    });

    ZOHO.BIGIN.CONFIG.getOrgInfo().then(function (response) {
      console.log("ZOHO.BIGIN.CONFIG.getOrgInfo: " + JSON.stringify(response, null, 2));
      $("#orgInfo").html(JSON.stringify(response));
    });

    var data_keys = { apiKeys: [baseURLAPIName] };
    ZOHO.BIGIN.API.getOrgVariable(data_keys).then(function (data) {
        console.log("ZOHO.BIGIN.API.getOrgVariable: " + JSON.stringify(data, null, 2));
        appURL = data.Success.Content;
        try {
          if (appURL != null) {
            $("#usdc").removeClass('disabled');
            $("#eudc").removeClass('disabled');
            $("#audc").removeClass('disabled');
            $("#otherdc").removeClass('disabled');
            if (appURL === "https://app.sms-magic.com") {
              $("#usdc").addClass('disabled');
            } else if (appURL === "https://eu.app.sms-magic.com") {
              $("#eudc").addClass('disabled');
            } else if (appURL === "https://aus-app.sms-magic.com") {
              $("#audc").addClass('disabled');
            } else {
              $("#otherdc").addClass('disabled');
            }
            $("#inputdcurl").html(appURL);
          }
        } catch (err) {
          console.error('Error in getting org valiable' + err);
        }
    });
  });
  ZOHO.embeddedApp.init();
});


